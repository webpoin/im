// global cookies object
(function (cookie) {
	'use strict';
	if (typeof (cookie) === 'undefined') {
		var Cookies = function (key, value, options) {
			return arguments.length === 1 ? Cookies.get(key) : Cookies.set(key, value, options);
		};

		// Allows for setter injection in unit tests
		Cookies._document = document;
		Cookies._navigator = navigator;

		Cookies.defaults = {
			path: '/'
		};

		Cookies.get = function (key) {
			if (Cookies._cachedDocumentCookie !== Cookies._document.cookie) {
				Cookies._renewCache();
			}
			return Cookies._cache[key];
		};

		Cookies.set = function (key, value, options) {
			options = Cookies._getExtendedOptions(options);
			options.expires = Cookies._getExpiresDate(value === undefined ? -1 : options.expires);

			Cookies._document.cookie = Cookies._generateCookieString(key, value, options);
			return Cookies;
		};

		Cookies.expire = function (key, options) {
			return Cookies.set(key, undefined, options);
		};

		Cookies._getExtendedOptions = function (options) {
			return {
				path: options && options.path || Cookies.defaults.path,
				domain: options && options.domain || Cookies.defaults.domain,
				expires: options && options.expires || Cookies.defaults.expires,
				secure: options && options.secure !== undefined ? options.secure : Cookies.defaults.secure
			};
		};

		Cookies._isValidDate = function (date) {
			return Object.prototype.toString.call(date) === '[object Date]' && !isNaN(date.getTime());
		};

		Cookies._getExpiresDate = function (expires, now) {
			now = now || new Date();
			switch (typeof expires) {
				case 'number':
					expires = new Date(now.getTime() + expires * 1000);
					break;
				case 'string':
					expires = new Date(expires);
					break;
			}

			if (expires && !Cookies._isValidDate(expires)) {
				throw new Error('`expires` parameter cannot be converted to a valid Date instance');
			}

			return expires;
		};

		Cookies._generateCookieString = function (key, value, options) {
			key = key.replace(/[^#$&+\^`|]/g, encodeURIComponent);
			key = key.replace(/\(/g, '%28').replace(/\)/g, '%29');
			value = (value + '').replace(/[^!#$&-+\--:<-\[\]-~]/g, encodeURIComponent);
			options = options || {};

			var cookieString = key + '=' + value;
			cookieString += options.path ? ';path=' + options.path : '';
			cookieString += options.domain ? ';domain=' + options.domain : '';
			cookieString += options.expires ? ';expires=' + options.expires.toUTCString() : '';
			cookieString += options.secure ? ';secure' : '';

			return cookieString;
		};

		Cookies._getCookieObjectFromString = function (documentCookie) {
			var cookieObject = {};
			var cookiesArray = documentCookie ? documentCookie.split('; ') : [];

			for (var i = 0; i < cookiesArray.length; i++) {
				var cookieKvp = Cookies._getKeyValuePairFromCookieString(cookiesArray[i]);

				if (cookieObject[cookieKvp.key] === undefined) {
					cookieObject[cookieKvp.key] = cookieKvp.value;
				}
			}

			return cookieObject;
		};

		Cookies._getKeyValuePairFromCookieString = function (cookieString) {
			// "=" is a valid character in a cookie value according to RFC6265, so cannot `split('=')`
			var separatorIndex = cookieString.indexOf('=');

			// IE omits the "=" when the cookie value is an empty string
			separatorIndex = separatorIndex < 0 ? cookieString.length : separatorIndex;

			return {
				key: decodeURIComponent(cookieString.substr(0, separatorIndex)),
				value: decodeURIComponent(cookieString.substr(separatorIndex + 1))
			};
		};

		Cookies._renewCache = function () {
			Cookies._cache = Cookies._getCookieObjectFromString(Cookies._document.cookie);
			Cookies._cachedDocumentCookie = Cookies._document.cookie;
		};

		Cookies._areEnabled = function () {
			var testKey = 'cookies.js';
			var areEnabled = Cookies.set(testKey, 1).get(testKey) === '1';
			Cookies.expire(testKey);
			return areEnabled;
		};

		Cookies.enabled = Cookies._areEnabled();
	}
	window.XFCOOKIE = Cookies;
})(window.XFCOOKIE);

// support JSON low for IE6
(function (json) {
	if (typeof (json) === 'undefined') {
		var _json = {};
		_json.parse = function (data) {
			return eval("(" + data + ")");
		};

		_json.stringify = function (object) {
			var type = typeof object;
			if ('object' == type) {
				if (Array == object.constructor)
					type = 'array';
				else if (RegExp == object.constructor)
					type = 'regexp';
				else
					type = 'object';
			}
			switch (type) {
				case 'undefined' :
				case 'unknown' :
					return;
					break;
				case 'boolean' :
				case 'regexp' :
					return object.toString();
					break;
				case 'number' :
					return isFinite(object) ? object.toString() : 'null';
					break;
				case 'string' :
					return '"' + object.replace(/(\\|\")/g, "\\$1").replace(/\n|\r|\t/g, function () {
						var a = arguments[0];
						return (a == '\n') ? '\\n' : (a == '\r') ? '\\r' : (a == '\t') ? '\\t' : ""
					}) + '"';
					break;
				case 'object' :
					if (object === null)
						return 'null';
					var results = [];
					for (var property in object) {
						var value = _json.stringify(object[property]);
						if (value !== undefined)
							results.push(_json.stringify(property) + ':' + value);
					}
					return '{' + results.join(',') + '}';
					break;
				case 'array' :
					var results = [];
					for (var i = 0; i < object.length; i++) {
						var value = _json.stringify(object[i]);
						if (value !== undefined)
							results.push(value);
					}
					return '[' + results.join(',') + ']';
					break;
			}
		};

		window.JSON = _json;
	}
}(window.JSON));

var XFStore = (function () {
	var _store = {};
	var _expires = 7 * 24 * 60 * 60;
	var _path = "/";

	_store.set = function (key, value, expires) {
		expires = expires ? expires : _expires;
		XFCOOKIE.set(key, value, {expires: expires, path: _path});
		return this;
	};

	_store.get = function (key) {
		return XFCOOKIE.get(key);
	};

	_store.del = function (key) {
		XFCOOKIE.expire(key, null);
		return this;
	};
	return _store;
}());

// platform and browser information
(function (collect) {
	if (typeof (collect) === 'undefined') {
		var ua = navigator.userAgent.toLowerCase(),
			pf = navigator.platform.toLowerCase(),
			ck = function (regex, obj) {
				return regex.test(obj || ua);
			},
			vr = function (is, regex) {
				var m;
				return (is && (m = regex.exec(ua))) ? parseFloat(m[1]) : 0;
			},
			f = {i:'', co:'', pv:'', ct:''};

		$.getScript("http://int.dpool.sina.com.cn/iplookup/?format=js", function(result){
			f.co = remote_ip_info.country;
			f.pv = remote_ip_info.province;
			f.ct = remote_ip_info.city;
		});

		var browser = (
			/* other must be here */
			(ck(/xiaomi/) && 'mi') || (ck(/htc/) && 'htc')
			|| (ck(/opera/) && 'opera') || (ck(/\bchrome\b/) && 'chrome') || (ck(/webkit/) && 'webkit')
			|| (ck(/safari/) && 'safari') || (ck(/msie/) && 'ie') || (ck(/gecko/) && 'gecko')
			|| (ck(/firefox/) && 'firefox') || 'other'
			);

		collect = {
			b: {
				bt: browser,
				bv: ( vr(browser === 'ie', /msie (\d+\.\d+)/) || vr(browser in ['opera', 'safari'], /version\/(\d+\.\d+)/)
					|| vr(true, new RegExp('\\b' + browser + '\\/(\\d+\\.\\d+)'))
					/* the other check must be here */
					|| 0
					)
			},
			p: {
				pt: ((ck(/windows|win32/) && 'win') || (ck(/macintosh|mac os x/) && 'mac')
					|| (ck(/iphone/, pf) && 'iphone') || (ck(/ipod/, pf) && 'ipod') || (ck(/ipad/) && 'ipad')
					|| (ck(/blackberry/) && 'blackberry') || (ck(/android/) && 'android') || (ck(/linux/) && 'linux')

					|| 'other'
					),
				pv: ((ua.indexOf("nt 6.1") > -1 && '7') || (ua.indexOf("nt 6.0") > -1 && 'vista') || (ua.indexOf("nt 5.2") > -1 && '2003')
					|| (ua.indexOf("nt 5.1") > -1 && 'xp') || (ua.indexOf("nt 5.0") > -1 && '2000')

					|| 'unknow'
					)
			},
			bs: {
				ce: navigator.cookieEnabled,
				je: navigator.javaEnabled(),
				l: navigator.language || navigator.browserLanguage || navigator.systemLanguage || navigator.userLanguage || "",
				sc: (window.screen.width || 0) + "x" + (window.screen.height || 0),
				cd: window.screen.colorDepth || 0,
				rf: document.referrer || '',
				u: document.location.href || '',
				h: window.location.host || '',
				f: f
			},
			// methods
			toJSONString: function () {
				return JSON.stringify(this);
			}
		};
		window.XFCOLLECT = collect;
	}
}(window.XFCOLLECT));

// session interactive in multi-pages
(function (config) {
	if (typeof (config) === 'undefined') {
		var _mod = {};
		var _baseStr = 'SES_';
		var _ruleFullMask = 0xFFFF; // max 16 session
		_mod.isPump = false;

		// get an id
		_mod.id = (function () {
			//debugger;
			var rule = XFStore.get(_baseStr + 'countrule') || 0;

			var id = 0;
			for (var i = 0; id <= _ruleFullMask; i++) {
				id = 1 << i;
				if ((id & rule) == 0) {
					XFStore.set(_baseStr + 'countrule', id | rule);
					return id;
				}
			}
			return 0;
		}());

		var _cache = (function () {
			var _maxSlotSize = 1024;
			var _curSlotSize = 0;
			var _pageCache = [];

			return {
				put: function (msg) {
					if (msg) {
						if (typeof (msg) === 'object') msg = JSON.stringify(msg);
						if (typeof (msg) !== 'string') return this;
						var hit = XFStore.get(_baseStr + 'hit') || 0;
						var rule = XFStore.get(_baseStr + 'countrule') || 0;

						// expire, clear (rule have marked all pages except current page)
						if ((hit ^ rule) == _mod.id) {
							hit = 0;
							XFStore.set(_baseStr + 'hit', 0);
							XFStore.del(_baseStr + 'cache');
							_curSlotSize = 0;
						}

						if ((hit ^ rule) != rule || (msg.length + _curSlotSize) > _maxSlotSize) {_pageCache.push(msg);}
						else {
							var cache = XFStore.get(_baseStr + 'cache');
							cache = cache ? JSON.parse(cache) : [];
							cache.push(msg);
							XFStore.set(_baseStr + 'cache', JSON.stringify(cache));
							_curSlotSize += msg.length;
						}
					}
					return this;
				},
				get: function (cb) {
					var hit = XFStore.get(_baseStr + 'hit') || 0;
					if ((hit & _mod.id)) return this;
					var cache = XFStore.get(_baseStr + 'cache');
					if (!cache) return this;

					// marked this package have been copy
					XFStore.set(_baseStr + 'hit', hit | _mod.id);
					(typeof (cb) === 'function') && cb(JSON.parse(cache));
					return this;
				},
				destroy: function () {
					XFStore.del(_baseStr + 'cache');
					return this;
				}
			};
		}());

		_mod.hasPump = function () {
			return XFStore.get(_baseStr + 'pump');
		};
		_mod.regPump = function () {
			XFStore.set(_baseStr + 'pump', _mod.id);
			var hit = XFStore.get(_baseStr + 'hit') || 0;
			XFStore.set(_baseStr + 'hit', hit & ~_mod.id);
			_mod.isPump = true;
			return this;
		};

		_mod.pump = function (cb) {
			_cache.get(cb);
			return this;
		};

		_mod.postMessage = function (msg) {
			var rule = XFStore.get(_baseStr + 'countrule') || 0;
			// only current session, don't caching
			if ((rule & ~_mod.id) != 0) {
				_cache.put(msg);
			}
			return this;
		};

		_mod.getAlertDialogState = function () {
			var state = XFStore.get(_baseStr + 'alertdlgstate');
			return state ? JSON.parse(state) : {};
		};
		_mod.setAlertDialogState = function (state) {
			typeof (state) === 'object' && (state = JSON.stringify(state));
			XFStore.set(_baseStr + 'alertdlgstate', state);
			return this;
		};
		_mod.getChatDialogState = function () {
			var state = XFStore.get(_baseStr + 'chatdlgstate');
			return state ? JSON.parse(state) : {};
		};
		_mod.setChatDialogState = function (state) {
			typeof (state) === 'object' && (state = JSON.stringify(state));
			XFStore.set(_baseStr + 'chatdlgstate', state);
			return this;
		};

		_mod.destroy = function () {
			var hit = XFStore.get(_baseStr + 'hit') || 0;
			var rule = XFStore.get(_baseStr + 'countrule') || 0;
			var pumpid = XFStore.get(_baseStr + 'pump') || 0;
			rule = rule & ~_mod.id;
			hit = hit & ~_mod.id;

			if (pumpid == _mod.id) XFStore.del(_baseStr + 'pump');
			// all pages closed
			if (rule == 0) {
				_cache.destroy();
				XFStore.del(_baseStr + 'alertdlgstate');
				XFStore.del(_baseStr + 'chatdlgstate');
				hit = 0;
			}
			XFStore.set(_baseStr + 'hit', hit);
			XFStore.set(_baseStr + 'countrule', rule);

			return this;
		};

		window.XFSESSION = _mod;
	}
}(window.XFSESSION));

var XFMessage = function (msg) {
	this.msg = {};
	var that = this;
	var init = function (msg) {
		try {
			if (typeof(msg) == 'string') that.msg = JSON.parse(msg);
			else if (typeof(msg) == 'object') that.msg = msg;
		} catch (e) {
			console.log('prase Message package exception.');
		}

		if (!that.msg.stamp) that.msg.stamp = currentStamp();
		return that;
	};

	this.getAction = function () {
		return this.msg.action;
	};

	this.getStatus = function () {
		return this.msg.status;
	};

	this.getReply = function () {
		return this.msg.reply;
	};

	this.getFlag = function () {
		return this.msg.flag;
	};

	this.getStamp = function () {
		return this.msg.stamp;
	};

	this.getMessage = function () {
		if (!this.msg.data) return "";
		return this.msg.data.message;
	};

	this.getHeader = function (name) {
		if (!this.msg.header) return "";
		return this.msg.header[name];
	};

	this.getMetaHeader = function (name) {
		if (!this.msg.metaheader) return "";
		return this.msg.metaheader[name];
	};

	this.getData = function (name) {
		if (!this.msg.data) return "";
		return this.msg.data[name];
	};

	this.getAgents = function () {
		if (!this.msg.data || !this.msg.data.agents) return [];
		return this.msg.data.agents;
	};

	this.getUser = function () {
		if (!this.msg.data || !this.msg.data.user) return {};
		return this.msg.data.user;
	};

	// setter
	this.setAction = function (action) {
		this.msg.action = action;
		return that;
	};

	this.setStatus = function (status) {
		this.msg.status = status;
		return that;
	};

	this.setReply = function (reply) {
		this.msg.reply = reply;
		return that;
	};

	this.setFlag = function (flag) {
		this.msg.flag = flag;
		return that;
	};

	this.setStamp = function (time) {
		this.msg.stamp = time;
		return that;
	};

	this.setHeader = function (name, value) {
		if (!this.msg.header) this.msg.header = {};
		this.msg.header[name] = value;
		return that;
	};

	this.setMetaHeader = function (name, value) {
		if (!this.msg.metaheader) this.msg.metaheader = {};
		this.msg.metaheader[name] = value;
		return that;
	};

	this.setData = function (name, value) {
		if (!this.msg.data) this.msg.data = {};
		this.msg.data[name] = value;
		return that;
	};

	this.setMessage = function (msg) {
		if (!this.msg.data) this.msg.data = {};
		this.msg.data["message"] = msg;
		return that;
	};

	this.updateStamp = function () {
		var stamp = currentStamp();
		this.setStamp(stamp);
		return that;
	};

	this.mergeHeader = function (headers, update) {
		if (typeof (headers) != 'object') return that;
		this.msg.header || (this.msg.header = {});
		for (var h in headers) {
			if (!update && typeof (this.msg.header[h]) !== 'undefined') continue;
			this.msg.header[h] = headers[h];
		}
		return that;
	};

	this.toString = function () {
		return JSON.stringify(this.msg);
	};

	this.toObject = function () {
		return this.msg;
	};

	function currentStamp() {
		return (Math.round(new Date().getTime() / 1000));
	}

	init(msg);
};

var XFNetwork = function (config) {
	var _mod = {};
	var _connected = false;
	var _beatTimer = 0;
	var _curInterval = 0;
	var _charset = document.characterSet || document.charset;

	var _config = {
		server: '',
		interval: 2000,
		features: {},
		onerror: function () {},
		onreceiveddata: function () {}
	};

	_mod.config = function (config) {
		if (typeof (config) === 'object') {
			for (var i in _config) {
				if (typeof (config[i]) !== 'undefined') _config[i] = config[i];
			}
		}
		return this;
	};

	_mod.run = function (interval) {
		_curInterval = interval || _config.interval;
		if (_beatTimer !== 0) _mod.stop();
		_beatTimer = setInterval(beat, _curInterval);
		return this;
	};

	_mod.runHighMode = function () {
		return _mod.run(_config / 8);
	};

	_mod.stop = function () {
		clearInterval(_beatTimer);
		_beatTimer = 0;
		_connected = false;
		return this;
	};

	_mod.on = function (evname, cb) {
		if (typeof (evname) === 'string' && typeof (cb) === 'function') {
			_config[evname] = cb;
		}
		return this;
	};

	_mod.features = function (key, value) {
		if (arguments.length === 1) {
			return _config.features[key];
		} else if (arguments.length === 0) {
			return _config.features;
		}

		if (typeof (key) === 'string' && typeof (value) !== 'undefined') {
			_config.features[key] = value;
		}
		return this;
	};

	_mod.send = function (data, success, failure) {
		if (!data) return this;
		if (typeof (data) === 'object') {
			// XFMessage package
			if (typeof (data.getAction) === 'function') {
				data.setHeader('charset', _charset);
				data.mergeHeader(_config.features);
				data = data.toString();
			} else {
				data.header || (data.header = {});
				data.header.chatset = _charset;
				for (var h in _config.features) {
					data.header[h] = _config.features[h];
				}
				data = JSON.stringify(data);
			}
		}
		jQuery.support.cors = true;
		$.ajax({
			url: _config.server,
			data: {data: data},
			async: false,
			dataType: "jsonp",
			jsonp: "callbackparam",
			jsonpCallback: "success_jsonpCallback"
		}).done(function (data) {
			typeof (success) === 'function' && success(data);
		}).fail(function (jqXHR, textStatus, errorThrown) {
			typeof (failure) === 'function' && failure(errorThrown);
		});
	};

	// private
	function beat() {
		if (!XFSESSION.hasPump()) {
			XFSESSION.regPump();
			// switch to normal mode
			if (_curInterval < _config.interval) {
				_mod.run();
			}
		}

		if (!XFSESSION.isPump) {
			XFSESSION.pump(function (data) {
				$.each(data, function (i, msg) {
					_config.onreceiveddata(msg);
				});
			});
		} else {
			_mod.send(
				{action: 'get'},
				function (data) {
					_connected = true;
					if (data && data.status != 'none') {
						XFSESSION.postMessage(data);
					}
					_config.onreceiveddata(data);
				},
				function (error) {
					_connected = false;
					_config.onerror(error);
				}
			);
		}
	}

	return _mod.config(config);
};

var XFMessager = (function () {
	var _xfmod = {};
	var _domain = window.location.host;
	var _timerRegister = 0;
	var _registered = false;

	var _config = {
		debug: false,
		server: 'http://192.168.1.222:5388',
		beatInterval: 3000,
		registerInterval: 5000
	};

	$.each(['onconnectsuccess', 'onconnectfailure', 'onregistersuccess',
			'onregisterfailure', 'onunregistersuccess', 'onunregisterfailure',
			'onconnectaccepted', 'onconnectaccepted', 'onserverinform',
			'onmessage', 'onsendsuccess', 'onsendfailure',
			'onsendmessagesuccess', 'onsendmessagefailure', 'onready', 'onerror',
			'onshutdown'],
		function (i, method) {
			_config[method] = function () {};
		}
	);

	var _networkCore = new XFNetwork({
		server: _config.server,
		interval: _config.beatInterval,
		onreceiveddata: ondReceivedData,
		onerror: onError
	});

	function onError(error) {
		_config.onerror(error);
	}

	function ondReceivedData(data) {
		var pck = new XFMessage(data);
		var action = pck.getAction();
		var reply = pck.getReply();
		var status = pck.getStatus();

		if (action == "response") {
			if (reply == "ringing") {
				if (status == "accepted") {
					_config.onconnectaccepted(pck);
				} else if (status == "rejected") {
					_config.onconnectrejected(pck);
				}
			}
		} else if (action == "message") {
			_config.onmessage(pck);
		} else if (action == "inform") {
			_config.onserverinform(pck);
		}
	}

	function register() {
		_networkCore.send(
			{action: 'register', header: {uid: XFCONFIG.uid, vid: XFStore.get('vid')}, metaHeader: XFCOLLECT},
			function (data) {
				var pck = new XFMessage(data);
				var status = pck.getStatus();
				if (status == "success") {
					_xfmod.abortRegister();
					_registered = true;
					XFStore.set('vid', pck.getHeader('vid')).set('uid', pck.getHeader('uid'));
					_config.onregistersuccess(pck);
					// run network to listen status
					_networkCore.features('sid', pck.getHeader('sid'))
						.features('uid', pck.getHeader('uid')).features('vid', pck.getHeader('vid'));
					_networkCore.run();
				} else {
					_config.onregisterfailure(pck);
				}
			},
			function (error) {
				_xfmod.log(error);
			}
		);
	}

	function unregister() {
		_networkCore.send({action: "unregister" },
			function (data) {
				var pck = new XFMessage(data);
				var status = pck.getStatus();
				if (status == "success") {
					_registered = false;
					_xfmod.abortRegister();
					_networkCore.stop();
					_config.onunregistersuccess(pck);
				} else {
					_config.onunregisterfailure(pck);
				}
			},
			function (error) {
				_xfmod.log(error);
			}
		);
	}

	_xfmod.run = function (config) {
		_xfmod.config(config);
		// catch global error
		window.onerror = function (error) {
			_config.onerror(error);
		};
		// must load jquery library
		if (typeof($) != 'function') {
			_config.onerror({error: 'NOJQUERY'});
			return null;
		}

		$(window).unload(function () {
			_config.onshutdown();
			//debugger;
			XFSESSION.destroy();
			//unregister();
		});

		if (!XFSESSION.hasPump()) {
			XFSESSION.regPump();
			_xfmod.register();
		} else {
			_networkCore.features('vid', XFStore.get('vid')).features('sid', XFStore.get('sid'))
				.features('uid', XFStore.get('uid')).features('aid', XFStore.get('aid'));
			_networkCore.runHighMode();
		}
		_config.onready();
		return this;
	};

	_xfmod.config = function (config) {
		if (typeof (config) === 'object') {
			for (var i in _config) {
				if (typeof (config[i]) !== 'undefined') _config[i] = config[i];
			}
		}
		return this;
	};

	_xfmod.on = function (method, cb) {
		if (typeof (method) === 'string' && typeof (cb) === 'function') {
			_config[method] = cb;
		}
		return this;
	};

	_xfmod.register = function () {
		if (!_timerRegister && _timerRegister === 0) {
			_timerRegister = setInterval(register, _config.registerInterval);
		}
		return this;
	};

	_xfmod.abortRegister = function () {
		if (_timerRegister !== 0) {
			clearInterval(_timerRegister);
			_timerRegister = 0;
		}
		return this;
	};

	_xfmod.log = function (msg) {
		if (!_config.debug || !msg) return this;
	};

	_xfmod.send = function (data, onsuccess, onfailure) {
		_networkCore.send(
			data,
			function (data) {
				var pck = new XFMessage(data);
				typeof (onsuccess) === 'function' ? onsuccess(pck) : _config.onsendsuccess(pck);
			},
			function (error) {
				typeof (onfailure) === 'function' ? onfailure(error) : _config.onsendfailure(error);
			}
		);
		return this;
	};

	_xfmod.connect = function (aid, onsuccess, onfailure) {
		_networkCore.send({action: "connect", header: {aid: aid}, metaHeader: XFCOLLECT},
			function (data) {
				var pck = new XFMessage(data);
				var status = pck.getStatus();
				if (status == "success") {
					_networkCore.features('sid', pck.getHeader('sid'));
					_networkCore.features('aid', pck.getHeader('aid'));
					XFStore.set('sid', pck.getHeader('sid')).set('aid', pck.getHeader('aid'));
					typeof (onsuccess) === 'function' ? onsuccess(pck) : _config.onconnectsuccess(pck);
				} else {
					_networkCore.features('sid', '');
					typeof (onfailure) === 'function' ? onfailure(pck) : _config.onconnectfailure(pck);
				}
			},
			function (error) {
				_xfmod.log(error);
			}
		);

		return this;
	};

	_xfmod.sendmessage = function (msg, onsuccess, onfailure) {
		if (!_networkCore.features('sid')) {
			var err = {errno: 'NOSESSION', error: 'no session with this agent.'};
			typeof (onfailure) === 'function' ? onfailure(err) : _config.onsendmessagefailure(err);
			return this;
		}

		_networkCore.send({action: "send", data: {message: msg}},
			function (data) {
				var pck = new XFMessage(data);
				var status = pck.getStatus();
				if (status == "success") {
					typeof (onsuccess) === 'function' ? onsuccess(pck) : _config.onsendmessagesuccess(pck);
				} else {
					typeof (onfailure) === 'function' ? onfailure(pck) : _config.onsendmessagefailure(pck);
				}
			},
			function (error) {
				_xfmod.log(error);
			}
		);

		return this;
	};

	_xfmod.command = function (cmd, onsuccess, onfailure) {
		if (!_networkCore.features('sid')) {
			var err = {errno: 'NOSESSION', error: 'no session with this agent.'};
			typeof (onfailure) === 'function' ? onfailure(err) : _config.onsendmessagefailure(err);
			return this;
		}

		_networkCore.send({action: "command", data: {command: cmd}},
			function (data) {
				var pck = new XFMessage(data);
				var status = pck.getStatus();
				if (status == "success") {
					typeof (onsuccess) === 'function' ? onsuccess(pck) : _config.onsendmessagesuccess(pck);
				} else {
					typeof (onfailure) === 'function' ? onfailure(pck) : _config.onsendmessagefailure(pck);
				}
			},
			function (error) {
				_xfmod.log(error);
			}
		);
		return this;
	};

	return _xfmod;
}());

function success_jsonpCallback(data) {
	return data;
}