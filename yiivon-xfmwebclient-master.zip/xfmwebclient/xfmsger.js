/**
 * Created by Yiivon on 2014/6/13.
 */
// global configuration
(function (config) {
	if (typeof (config) === 'undefined') {
		window.XFCONFIG = {
			uid: '',
			run: 'manual'   // auto - automate run
			// manual - need invoke run method to run
		};

		window.XFCONFIG.path = (function (script, i, me){
			var l = script.length;
			for (; i < l; i++){
				me = !!document.querySelector ?	script[i].src : script[i].getAttribute('src', 4);
				if (me.substr(me.lastIndexOf('/')).indexOf('xfmsger') !== -1)
					break;
			}

			me = me.split('?');
			window.XFCONFIG.args = me[1];
			if(window.XFCONFIG.args){
				var p = window.XFCONFIG.args.split('&'), a;
				for(i=0; i< p.length; i++){
					a = p[i].split('=');
					if(a.length === 2) window.XFCONFIG[a[0]] = a[1];
				}
			}

			return me[0].substr(0, me[0].lastIndexOf('/') + 1);
		})(document.getElementsByTagName('script'), 0);
	}
}(window.XFCONFIG));

// dynamic loader for js, css
var XFLibLoader = (function () {
	var _mod = {};
	var _host = '';

	_mod.load = function (config) {
		if (!config) return false;
		if (typeof (config) === 'string') config = {libs: [config]};
		if (typeof(config.length) === 'number') config = {libs: config};
		if (typeof (config.libs) !== 'object') return false;
		config.loaded || (config.loaded = function () {});
		config.host && (_host = config.host);

		config.libs.count = config.libs.length;
		if (config.order) {
			orderLoad(config.libs, config.loaded);
		} else {
			while (config.libs.length > 0) {
				var item = shiftItem(config.libs);
				if (!item) break;

				loadLibrary(item.file, item.type, function () {
					item.loaded();
					--config.libs.count;
					if (config.libs.count < 1) config.loaded();
				});
			}
		}
	};

	function shiftItem(libs) {
		var item = libs.shift();
		if (!item) return null;

		if (typeof (item) === 'string') item = {file: item};
		item.type || (item.type = 'js');
		item.loaded || (item.loaded = function () {});
		return item;
	}

	function orderLoad(libs, loaded) {
		var item = shiftItem(libs);
		if (!item) return false;

		loadLibrary(item.file, item.type, function () {
			item.loaded();
			--libs.count;
			if (libs.count < 1) {
				loaded();
			} else {
				orderLoad(libs, loaded);
			}
		});

		return true;
	}

	// private methods
	function loadLibrary(filename, type, onload) {
		if (_host) filename = _host + "/" + filename;
		var oHead = document.getElementsByTagName('HEAD').item(0);
		var fileref = null;
		if (type == 'css') {
			fileref = document.createElement("link");
			fileref.rel = "stylesheet";
			fileref.type = "text/css";
			fileref.href = filename;
		} else {
			fileref = document.createElement("script");
			fileref.type = "text/javascript";
			fileref.src = filename;
		}

		if (typeof(fileref.onload) === 'undefined') {
			fileref.onreadystatechange = function () {
				if (this.readyState == "complete" || this.readyState == "loaded") {
					fileref.onreadystatechange = null;
					onload && onload();
				}
			}
		} else {
			fileref.onload = onload;
		}

		if (fileref) oHead.appendChild(fileref);
	}

	return _mod;
}());

// UI extend
var XFUiExtend = function(){
	$.dialog.fn.shake = function()
	{
		var style = this.DOM.wrap[0].style,
			p = [4, 8, 4, 0, -4, -8, -4, 0],
			fx = function(){
				style.marginLeft = p.shift() + 'px';
				if(p.length <= 0){
					style.marginLeft = 0;
					clearInterval(timerId);
				}
			};
		p = p.concat(p.concat(p));
		timerId = setInterval(fx, 13);
		return this;
	};
};

var XFAlertList = function(config){
	var _config = {
		title:  '7 x 24 客服',
		left: '98%',
		top: '42%',
		items: [],
		header: true,
		footer: true,
		show: function(){},
		close: function(){},
		itemclick: function(){}
	};
	if(config) for(var i in _config){ if(config[i]) _config[i] = config[i];  }


	var _tplHeader = '<div class="header">' +
					'	<img src="images/service-girl.png" class="logo">'+
					'	<div class="caption">'+
					'		<div class="small">'+
					'		service'+
					'		</div>'+
					'		<div class="big">'+
					'		客服中心'+
					'		</div>'+
					'	</div>'+
					'	</div>'+
					'	<hr style="width:146px;margin:0;background-color:#000">';

	var _tplFooter = '<hr style="width: 146px; margin-top:10px; background-color: #000000; float: left;"/>'+
						'<div class="footer">'+
							'<img src="images/clock.png" class="logo"/>'+
							'<div class="caption">'+
								'<div class="small">'+
									'服务时间'+
								'</div>'+
								'<div class="big">'+
									'9:00 - 24:00'+
								'</div>'+
							'</div>'+
							'<div class="bottom-label">'+
								'offer 7 x 24h services'+
							'</div>'+
						'</div>';

	var _dlg = $.dialog({
		title:_config.title,
		min: false,
		max: false,
		fixed: true,
		left: _config.left,
		top: _config.top,
		init: function () {
			var box = '	<div id="xfm-svr-list-box" class="xfm-svr-list-box" >';
			if(_config.header) box += _tplHeader;
			box += '<div id="xfm-svr-list-content"></div>';
			if(_config.footer) box += _tplFooter;
			box += '</div>';
			return this.content(box);
		},
		close: function(){
			this.hide();
			typeof (_config.close)=='function'&&_config.close({show:false, title:_config.title});
			return false;
		},
		resize: false,
		padding: 0
	}).hide();


	var _itemTpl = '<div class="xfm-svr-list-item"><img src="images/svr-list-item-logo.png" class="logo"> </div>';
	var _itemHeadTpl = '<div class="xfm-svr-list-head-item"></div>';

	return function(){
		var _cls = {};
		var _boxContent = $('#xfm-svr-list-content');
		var _itemBase = 'xfm-item-';

		_cls.show = function(cfg){
			cfg || (cfg={show:true});
			cfg.title && (_dlg.title(cfg.title));
			cfg.show || (cfg.show=false);

			if(cfg.show) _dlg.show();
			else _dlg.hide();

			_config.show({show:cfg.show, title:_config.title});
			return this;
		};

		_cls.close = function(){
			_dlg.hide();
			_config.close({show:false, title:_config.title});
			return this;
		};

		_cls.title = function(title){
			if(typeof (title) === 'string'){
				_dlg.title(title);
				_config.title = title;
			}
			return this;
		};

		_cls.addItem = function(item, pos){
			if(!item ) return this;
			if(typeof(item) !== 'object') item = {title:item};
			item.click = item.click || function(){};
			var itemId = (item.id || (new Date).getTime());
			item.id =  _itemBase + itemId;

			var node = item.head?$(_itemHeadTpl):$(_itemTpl);
			node.append(item.title);
			node.attr('id', item.id);
			if(!item.head){
				node.click(function(){item.click(itemId, item, node) || _config.itemclick(itemId, item, node);});
			}

			if(!pos){
				_boxContent.append(node);
			}else{
				_boxContent.prepend(node);
			}
			return this;
		};

		_cls.addItems = function(items, append){
			if(typeof (items) !== 'object') return this;
			if(!append) _cls.clear();
			$.each(items, function(i, v){
				_cls.addItem(v);
			});

			return this;
		};

		_cls.removeItem = function(id){
			if(id) $('#'+_itemBase+id).remove();
			return this;
		};

		_cls.clear = function(){
			_boxContent.html('');
			return this;
		};

		// initialize
		_cls.addItems(_config.items);
		return _cls;
	}();
};


var XFChatBox = function(config){
	var _template =
		'<div style="height: 280px; width: 300px;">'+
		'<div  class="xfm-chat-box">'+
		'<div id="xfm-chat-msg-viewer-scroll" class="xfm-chat-msg-viewer-scroll">'+
		'<table id="xfm-chat-msg-viewer" style="width: 100%; table-layout: fixed; ">'+
		'</table>'+
		'</div>'+
		'<div class="xfm-chat-box-mid-bar xfm-tool-bar">'+
		'	    <div id="xfm-tool-btn-emotion" class="xfm-tool-button"></div>'+
		'       <div id="xfm-tool-btn-flush" class="xfm-tool-button"></div>'+
		'</div>'+
		'<div style="clear: both;"></div>'+
		'<div id="xfm-chat-box-input-editor" class="xfm-chat-box-input-box" contenteditable="true"></div>'+
		'<div id="xfm-tool-btn-send"></div>'+
		'</div>'+
		'</div>';

	var _config = {
		title:  '客服 ',
		left: '99%',
		top: '70%',
		items: [],
		show: function(){},
		close: function(){},
		sendmessage: function(){},
		flush: function(){}
	};
	if(config) for(var i in _config){ if(config[i]) _config[i] = config[i];  }

	var _dlg = $.dialog({
		title:_config.title,
		min: false,
		max: false,
		fixed: true,
		content: _template,
		left: _config.left,
		top: _config.top,
		close: function(){
			this.hide();
			typeof(_config.close)=='function'&&_config.close({show:false, title:_config.title});
			return false;
		},
		resize: false,
		padding: 0
	}).hide();

	var _editor = $('#xfm-chat-box-input-editor');
	var _msgViewer = $('#xfm-chat-msg-viewer');
	var _msgViewerScroll = $('#xfm-chat-msg-viewer-scroll');

	var _emotionDlg = function(){
		var _set = (function () {
			var amount = 76;
			var box = $('<div class="xfm-chat-box-emotion-box"></div>');
			var tb = $('<table style="margin: 0; padding: 0"></table>');
			for (var i = 1; i < amount; i++) {
				var tr = $('<tr></tr>');
				for(var j=0;j<8&&i<amount; i++, j++){
					var td = $('<td></td>');
					var img = $('<img />');
					img.attr('src', 'images/emotion/'+i+'.gif');
					td.append(img);
					tr.append(td);
				}
				tb.append(tr);
			}
			return box.append(tb);
		}());

		var _edlg = $.dialog({
			title: false,
			padding: 0,
			fixed: true,
			init: function(){
				this.content(_set);
			}
		}).hide();

		_edlg.DOM.wrap.find('img').click(function(e){
			_editor.append(e.target.outerHTML);
			_edlg.hide();
		});

		return _edlg;
	}();

	_dlg.DOM.wrap.click(function(e){
		if(e.target.id !== "xfm-tool-btn-emotion"){
			_emotionDlg.hide();
		}
	});

	$('#xfm-tool-btn-emotion').click(function(e){
		_emotionDlg.position(e.clientX+3, e.clientY- _emotionDlg.DOM.wrap.height()-3);
		_emotionDlg.zindex(this.zIndex+10);
		_emotionDlg.show();
	});

	$('#xfm-tool-btn-flush').click(function(e){
		_dlg.shake();
		_config.flush();
	});

	return function(){
		var _cls = {};

		_cls.show = function(cfg){
			cfg || (cfg={show:true});
			cfg.title && (_dlg.title(cfg.title));
			cfg.show || (cfg.show=false);

			if(cfg.show) _dlg.show();
			else _dlg.hide();

			_config.show({show:cfg.show, title:_config.title});
			return this;
		};

		_cls.close = function(){
			_dlg.hide();
			_config.close({show:false, title:_config.title});
			return this;
		};

		_cls.title = function(title){
			_dlg.title(title);
			_config.title = title;
			return this;
		};

		_cls.clear = function(){
			_msgViewer.html('');
		};

		_cls.insertMessage = function (msg, self) {
			if(!msg) return this;
			if(typeof (msg) === 'string') msg = {message:msg};

			var row = $('<tr></tr>');
			var rowCol = $('<td style="white-space: nowrap;"></td>');
			var decorate = $('<img />');
			var logo = $('<img />');

			var content = $('<div></div>');
			content.html(msg.message);
			if(self){
				logo.attr('src', 'images/logo/user-online.png');
				logo.attr('class', 'xfm-chat-box-view-item-logo-r');
				decorate.attr('class', 'xfm-chat-box-view-item-content-decr-r');
				decorate.attr('src', 'images/msg-item-r.png');
				content.attr('class', 'xfm-chat-box-view-item-content-r');
			}else{
				logo.attr('src', 'images/logo/user-offline.png');
				logo.attr('class', 'xfm-chat-box-view-item-logo-l');
				decorate.attr('class', 'xfm-chat-box-view-item-content-decr-l');
				decorate.attr('src', 'images/msg-item-l.png');
				content.attr('class', 'xfm-chat-box-view-item-content-l');
			}

			rowCol.append(logo);
			rowCol.append(decorate);
			rowCol.append(content);
			row.append(rowCol);

			_msgViewer.append(row);
			_msgViewerScroll.scrollTop(_msgViewerScroll[0].scrollHeight);
		};

		// private method
		function sendMessage() {
			var msg = _editor.html();
			if(!msg) return;
			_config.sendmessage(msg);
			_cls.insertMessage(msg, true);
			_editor.html('');
			_editor.focus();
		}

		// events bind
		_editor.keydown(function(e){
			if(e.keyCode == 13){
				sendMessage();
				return false;
			}
		});

		$('#xfm-tool-btn-send').click(function (e) {
			sendMessage();
		});

		return _cls;
	}();
};

var XfmsgerUI = (function () {
    var _host = "http://192.168.1.222/xfmsger";
    var _xfmod = {};
	var _currentAid = '';
	var _initialized = false;
	var _alertList = null;
	var _chatDlg = null;

    function formatDate(date, format) {
        if (!date) return;
        if (!format) format = "yyyy-MM-dd";
        switch(typeof date) {
            case "string":
                date = new Date(date.replace(/-/, "/"));
                break;
            case "number":
                date = new Date(date*1000);
                break;
        }
        if (!date instanceof Date) return;
        var dict = {
            "yyyy": date.getFullYear(),
            "M": date.getMonth() + 1,
            "d": date.getDate(),
            "H": date.getHours(),
            "m": date.getMinutes(),
            "s": date.getSeconds(),
            "MM": ("" + (date.getMonth() + 101)).substr(1),
            "dd": ("" + (date.getDate() + 100)).substr(1),
            "HH": ("" + (date.getHours() + 100)).substr(1),
            "mm": ("" + (date.getMinutes() + 100)).substr(1),
            "ss": ("" + (date.getSeconds() + 100)).substr(1)
        };
        return format.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g, function() {
            return dict[arguments[0]];
        });
    }

	function loadNecessaries(){
		XFLibLoader.load({
			host: _host,
			libs: [{file:'css/xfmsger.css', type:'css'}, 'lhgdialog/lhgdialog.js?self=true&skin=jtop', 'libxfmsger.js'],
			order: true,
			loaded: reallyRun
		});
	}

	function reallyRun(){
		// NOTE: must open the UI extend first
		new XFUiExtend();

		_chatDlg || (_chatDlg = new XFChatBox({
			sendmessage: function(data){
				XFMessager.sendmessage(
					data,
					function(data){

					},
					function(error){
						if(error.errno === 'NOSESSION'){
							_chatDlg.insertMessage('对不起！客服不在线，无法发送消息。', false);
						}
					}
				);
			},
			flush: function(){
				XFMessager.command(
					'flush',
					function(data){

					},
					function(error){
						if(error.errno === 'NOSESSION'){
							_chatDlg.insertMessage('对不起！客服不在线，无法抖动。', false);
						}
					}
				);
			},
			show: function(state){
				XFSESSION.setChatDialogState(state);
			},
			close: function(state){
				XFSESSION.setChatDialogState(state);
				_alertList.show();
			}
		})).show(XFSESSION.getChatDialogState());

		_alertList || (_alertList = new XFAlertList({
			itemclick: function(id, item, e){
				if(_currentAid != id) {
					_chatDlg.clear();
					_currentAid = id;
				}

				_alertList.close();
				_chatDlg.title(item.title);
				_chatDlg.show();
				XFMessager.connect(
					id,
					function(data){

					},
					function(error){

					}
				);
			},
			show: function(state){
				XFSESSION.setAlertDialogState(state);
			},
			close: function(state){
				XFSESSION.setAlertDialogState(state);
			}
		})).show(XFSESSION.getAlertDialogState());


		var config = {
			debug: true,
			beatInterval: 2500,
			onregistersuccess: function (msg) {
				var user = msg.getUser();
				var agents = msg.getAgents();

				_alertList.title(user.displayname);
				_alertList.addItem({title:'销售客服', head:true});
				$.each(agents, function(i, item){
					_alertList.addItem({id:item.aid, title:item.displayname, status:item.status});
				});
				_alertList.show();
			},
			onserverinform: function(msg){

			},
			onconnectaccepted: function (msg) {

			},
			onmessage: function (msg) {
				_chatDlg.insertMessage(msg.getMessage(), false);
			},
			onready: function () {
			}
		};

		XFMessager.run(config);
	}

    _xfmod.run = function () {
	    if(_initialized) return this;
	    _initialized = true;

        // must load jquery library
        if (typeof($) != 'function') {
            // not yet load jquery, try load
            return XFLibLoader.load({host:_host, libs:['js/jquery.js'], loaded:loadNecessaries});
        }else{
	        loadNecessaries();
        }
	    return this;
    };

	if(XFCONFIG.run === 'auto'){
		_xfmod.run();
	}
    return _xfmod;
}());