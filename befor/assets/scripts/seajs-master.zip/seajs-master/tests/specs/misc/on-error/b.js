define(function() {
  error_b
})
