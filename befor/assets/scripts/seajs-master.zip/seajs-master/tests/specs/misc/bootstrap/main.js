define(function(require) {

  var test = require('../../../test')

  test.assert(true, 'inline bootstrap is ok')
  test.next()

})

