define(function(require, exports) {

  exports.message = '你好 UTF-8'

});
