define([
  // The simplest example
  'math',

  'anonymous',
  'anywhere',
  'cache',
  'chain',
  //'circular',
  'define',
  'dependencies',
  'duplicate-load',
  'exports',
  'jsonp',
  'lazy',
//  'load-css',
  'method',
  'multi-load',
  'multi-versions',
  'override',
  'public-api',
  'require-async',
  'require-global',
  'singleton',
  'transitive',

  // Place `path-resolve` at last because 404 case in it, otherwise it will
  // affect the following spec in old browsers such as Firefox 5.0
  'path-resolve'
])

