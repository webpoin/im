define(function(require, exports) {
  require('./c.js')

  exports.name = 'b'
})