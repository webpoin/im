define(function(require, exports) {
  exports.name = 'a'
  exports.b = require('./b')
});
