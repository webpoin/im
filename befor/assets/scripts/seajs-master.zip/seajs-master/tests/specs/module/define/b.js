define([], function(require, exports) {
  exports.name = 'b'
});
