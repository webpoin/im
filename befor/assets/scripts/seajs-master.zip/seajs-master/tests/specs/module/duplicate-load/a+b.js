define('a', [], { name: 'a' });
define('b', [], { name: 'b' });
